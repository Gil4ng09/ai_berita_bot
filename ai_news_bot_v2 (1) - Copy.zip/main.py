import configparser
import schedule
import time
from telegram import Bot

def get_news():
    return "Berita pagi ini: Dunia makin panas 🔥, ekonomi goyang, tapi kopi tetep enak ☕."

def send_news():
    config = configparser.ConfigParser()
    config.read('config.ini')
    token = config["telegram"]["bot_token"]
    chat_id = config["telegram"]["chat_id"]
    bot = Bot(token=token)
    bot.send_message(chat_id=chat_id, text=get_news())

def main():
    schedule.every().day.at("07:00").do(send_news)
    while True:
        schedule.run_pending()
        time.sleep(1)

if __name__ == "__main__":
    main()